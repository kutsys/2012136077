#include <stdio.h>
int InBar()	{
	printf("This file is bar.c.\n");
	return 0;
}
