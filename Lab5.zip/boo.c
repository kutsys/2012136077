#include <stdio.h>
int InBoo()	{
	printf("This file is boo.c.\n");
	return 0;
}
