#include <stdio.h>
int InFoo()	{
	printf("This file is foo.c.\n");
	return 0;
}
