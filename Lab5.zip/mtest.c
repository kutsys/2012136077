#include <stdio.h>
int main()	{
	InFoo();
	InBar();
	InBoo();
	return 0;
}
